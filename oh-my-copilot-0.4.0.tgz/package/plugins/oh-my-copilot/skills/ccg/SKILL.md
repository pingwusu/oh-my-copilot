---
name: ccg
description: Claude-Codex-Gemini tri-model orchestration via /ask codex + /ask gemini, then the omcp synthesizer combines results
level: 5
model:
  claude: claude-opus-4.7
  gpt: gpt-5.4
---

# CCG - Claude-Codex-Gemini Tri-Model Orchestration

CCG routes through the canonical `/ask` skill (`/ask codex` + `/ask gemini`), then the active omcp session synthesizes both outputs into one answer.

Use this when you want parallel external perspectives without launching tmux team workers.

## When to Use

- Backend/analysis + frontend/UI work in one request
- Code review from multiple perspectives (architecture + design/UX)
- Cross-validation where Codex and Gemini may disagree
- Fast advisor-style parallel input without team runtime orchestration

## Requirements

- **Codex CLI**: `npm install -g @openai/codex` (or `@openai/codex`)
- **Gemini CLI**: `npm install -g @google/gemini-cli`
- `omcp ask` command available
- If either CLI is unavailable, continue with whichever provider is available and note the limitation

## How It Works

```text
1. The active session decomposes the request into two advisor prompts:
   - Codex prompt (analysis/architecture/backend)
   - Gemini prompt (UX/design/docs/alternatives)

2. The session runs via CLI (skill nesting not supported):
   - `omcp ask codex "<codex prompt>"`
   - `omcp ask gemini "<gemini prompt>"`

3. Artifacts are written under `.omcp/artifacts/ask/`

4. The session synthesizes both outputs into one final response
```

## Execution Protocol

When invoked, the active omcp session MUST follow this workflow:

### 1. Decompose Request
Split the user request into:

- **Codex prompt:** architecture, correctness, backend, risks, test strategy
- **Gemini prompt:** UX/content clarity, alternatives, edge-case usability, docs polish
- **Synthesis plan:** how to reconcile conflicts

### 2. Invoke advisors via CLI

> **Note:** Skill nesting (invoking a skill from within an active skill) is not supported in Copilot CLI. Always use the direct CLI path via Bash tool.

Run both advisors:

```bash
omcp ask codex "<codex prompt>"
omcp ask gemini "<gemini prompt>"
```

### 3. Collect artifacts

Read latest ask artifacts from:

```text
.omcp/artifacts/ask/codex-*.md
.omcp/artifacts/ask/gemini-*.md
```

### 4. Synthesize

Return one unified answer with:

- Agreed recommendations
- Conflicting recommendations (explicitly called out)
- Chosen final direction + rationale
- Action checklist

## Fallbacks

If one provider is unavailable:

- Continue with available provider + omcp synthesis
- Clearly note missing perspective and risk

If both unavailable:

- Fall back to an omcp-only answer and state CCG external advisors were unavailable

## Invocation

```bash
/oh-my-copilot:ccg <task description>
```

Example:

```bash
/oh-my-copilot:ccg Review this PR - architecture/security via Codex and UX/readability via Gemini
```
